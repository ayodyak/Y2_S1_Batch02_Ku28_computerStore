package org.computerspareparts.csms.global.dto;

public class DeliveryItemDto {
    public Integer partId;
    public Integer quantity;
    public Double unitPrice; // optional
}

